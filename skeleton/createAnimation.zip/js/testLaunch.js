document.write("<script src=js/tool/OrbitControls.js></script>");
document.write("<script src=js/tool/UI.js></script>");
document.write("<script src=js/tool/Referee.js></script>");
document.write("<script src=js/tool/OrbitControls.js></script>");
document.write("<script src=js/tool/PlayerControl.js></script>");

document.write("<script src='js/SkinnedMeshController.js'></script>");
document.write("<script src='js/ParamMeasure.js'></script>");
document.write("<script src='js/test.js'></script>");