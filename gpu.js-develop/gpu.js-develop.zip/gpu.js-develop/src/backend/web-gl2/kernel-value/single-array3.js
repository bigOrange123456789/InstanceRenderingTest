const { WebGLKernelValueSingleArray3 } = require('../../web-gl/kernel-value/single-array3');

class WebGL2KernelValueSingleArray3 extends WebGLKernelValueSingleArray3 {}

module.exports = {
  WebGL2KernelValueSingleArray3
};