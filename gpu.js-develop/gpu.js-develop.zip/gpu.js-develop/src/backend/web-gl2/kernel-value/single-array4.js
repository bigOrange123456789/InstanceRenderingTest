const { WebGLKernelValueSingleArray4 } = require('../../web-gl/kernel-value/single-array4');

class WebGL2KernelValueSingleArray4 extends WebGLKernelValueSingleArray4 {}

module.exports = {
  WebGL2KernelValueSingleArray4
};