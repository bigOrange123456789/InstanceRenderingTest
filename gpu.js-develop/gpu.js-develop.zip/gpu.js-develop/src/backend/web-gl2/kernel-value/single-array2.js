const { WebGLKernelValueSingleArray2 } = require('../../web-gl/kernel-value/single-array2');

class WebGL2KernelValueSingleArray2 extends WebGLKernelValueSingleArray2 {}

module.exports = {
  WebGL2KernelValueSingleArray2
};