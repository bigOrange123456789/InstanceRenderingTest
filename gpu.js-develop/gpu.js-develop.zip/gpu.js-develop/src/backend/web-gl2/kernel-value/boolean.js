const { WebGLKernelValueBoolean } = require('../../web-gl/kernel-value/boolean');

class WebGL2KernelValueBoolean extends WebGLKernelValueBoolean {}

module.exports = {
  WebGL2KernelValueBoolean
};