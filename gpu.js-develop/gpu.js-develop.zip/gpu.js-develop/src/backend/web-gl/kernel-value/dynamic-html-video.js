const { WebGLKernelValueDynamicHTMLImage } = require('./dynamic-html-image');

class WebGLKernelValueDynamicHTMLVideo extends WebGLKernelValueDynamicHTMLImage {}

module.exports = {
  WebGLKernelValueDynamicHTMLVideo
};