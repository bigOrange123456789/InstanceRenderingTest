const { utils } = require('../../../utils');
const { WebGLKernelValueFloat } = require('../../web-gl/kernel-value/float');

class WebGL2KernelValueFloat extends WebGLKernelValueFloat {}

module.exports = {
  WebGL2KernelValueFloat
};