const { utils } = require('../../../utils');
const { WebGL2KernelValueHTMLImage } = require('./html-image');

class WebGL2KernelValueHTMLVideo extends WebGL2KernelValueHTMLImage {}

module.exports = {
  WebGL2KernelValueHTMLVideo
};